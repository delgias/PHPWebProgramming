<?php


$deleteID2 = $_GET['id'];

$file = fopen("data.txt", "r");
$myArray = array();
$count = 0;


while (! feof($file))
{
    $myArray [$count] = fgetcsv($file);

    $count = $count + 1;

}

fclose($file);

$newLine = "\r\n";


$counterValue = $count - 1;
$arrayToDeleteID = array();
$arrayExploded = array ();
$newArrayAfterDeletion = array();


foreach ($myArray as $d) {
    foreach($d as $v) {
        $arrayToDeleteID [$counterValue] = $v;

        $counterValue --;
    }
}

$n1 = 0;


$x = delete($count, $arrayToDeleteID, $arrayExploded, $newArrayAfterDeletion, $deleteID2);



if ($x == 25)
{
// 25 when it didn't find what it wanted to delete
echo "Unable to locate the specified ID to delete.  Please try again.";
}
else
{
		header ("Location:  display.php");
exit ();

}



function delete ($count, $arrayToDeleteID, $arrayExploded, $newArrayAfterDeletion, $deleteID2)
{
    $deleteID = $deleteID2;
    $deleteCounter = $count - 1; //  counter used for deleting
    $newArrayDeleteCounter = $count - 1; //counter used when creating new array without deleted element
    $countWriteData = $count - 1; //  counter variable used when writing data

    $countValue = 0;

    while ($deleteCounter > 0)  //  explode array to retrive ID
    {

        $arrayExploded [$deleteCounter]  = (explode("|",$arrayToDeleteID[$deleteCounter]));

        $deleteCounter --;
    }

    $countForDeleteSearch = $count -1;
    $elementNotFound = "value found";
    $countElements = 0;

    while ($countForDeleteSearch > 0) //  traverse array
    {
        if ($arrayExploded [$countForDeleteSearch] [0] == $deleteID) //  match ID to delete
        {
            while ($newArrayDeleteCounter > 0) //Put elements back in array with deleted element gone
            {
                if ($newArrayDeleteCounter == $countForDeleteSearch) //  don't put deleted element back in array
                {
                    $newArrayAfterDeletion [$newArrayDeleteCounter] = "garbage";
                    //Echo "Ping";
                    $countWriteData --;
                    $countElements ++;
                }
                else //  put every element back in array
                {
                    $newArrayAfterDeletion [$newArrayDeleteCounter]  = $arrayToDeleteID [$newArrayDeleteCounter];

                }


                $newArrayDeleteCounter --;
            }
        }
        $countForDeleteSearch --;
    }

    if ($countElements == 0) //  this number if > 0 if the item to delete is found in the file.  if the element is not found, it will return without attempting to delete a null value
    {
	//$testValue = 25;
        return 25;
    }
    else
    {
        $stringD = "data.txt";
        unlink ($stringD);
    }



    $textFile = "data.txt";

    $fileHandler = fopen($textFile, 'a') or die ("can't open file..");


    $countWriteData ++;
    $space = "|";

    while ($countWriteData > 0)
    {

        if ($newArrayAfterDeletion [$countWriteData] != "garbage")
        {
            $writeLine = $newArrayAfterDeletion [$countWriteData];
            $nowTime = time ();

            $time = time ();



            $nowTime3 = date ("g:i a.", time ());


            $nowDate = date("Y/m/d");

            fwrite($fileHandler, $writeLine);
            fwrite($fileHandler, "\r\n");

            $countWriteData --;
        }
        else // in garbage
        {
            $countWriteData --;
        }
    }

    fclose($fileHandler);

}


?>