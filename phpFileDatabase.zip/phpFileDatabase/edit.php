<?php


$userInputOrder = $_GET['order'];



$editID = $_GET['id'];

$editFirstName = $_GET['newFirstName'];
$editLastName = $_GET['newLastName'];
$editFavoriteSport = $_GET['newFavoriteSport'];
$newID = $_GET['newID'];

$userInputOrder = "asc";

$file = fopen("data.txt", "r");
$myArray = array();
$count = 0;

while (! feof($file)) // no need to lock the file here as this is just a reader.  the file is locked below when it is written to
{
    $myArray [$count] = fgetcsv($file);

    $count = $count + 1;

}
fclose($file);

$newLine = "\r\n";

$counterValue = $count - 1;
$arrayToDeleteID = array();
$arrayExploded = array ();
$newArrayAfterDeletion = array();

foreach ($myArray as $d) {
    foreach($d as $v) {
        $arrayToDeleteID [$counterValue] = $v;

        $counterValue --;
    }
}

$n1 = 0;


$x = delete($count, $arrayToDeleteID, $arrayExploded, $newArrayAfterDeletion, $editID, $editFirstName, $editLastName, $editFavoriteSport, $newID);




if ($x == 25)
{
// 25 when it didn't find what it wanted to delete
echo "Unable to locate the specified ID to edit.  Please try again.";
}
else
{
		header ("Location:  display.php");
exit ();

}



function delete ($count, $arrayToDeleteID, $arrayExploded, $newArrayAfterDeletion, $editID, $editFirstName, $editLastName, $editFavoriteSport, $newID)
{
    $deleteID = $editID;
    $deleteCounter = $count - 1; //  counter used for deleting
    $newArrayDeleteCounter = $count - 1; //counter used when creating new array without deleted element
    $countWriteData = $count - 1; //  counter variable used when writing data

    $countValue = 0;

    while ($deleteCounter > 0)  //  explode array to retrive ID
    {

        $arrayExploded [$deleteCounter]  = (explode("|",$arrayToDeleteID[$deleteCounter]));

        $deleteCounter --;
    }

    $countForDeleteSearch = $count -1;

    $countElements = 0;

    while ($countForDeleteSearch > 0) //  traverse array
    {
        if ($arrayExploded [$countForDeleteSearch] [0] == $deleteID) //  match ID to delete
        {
            while ($newArrayDeleteCounter > 0) //Put elements back in array with deleted element gone
            {
                if ($newArrayDeleteCounter == $countForDeleteSearch) //  don't put deleted element back in array
                {

                    $nowTime3 = date ("g:i a.", time ());

                    // $nowTime2 = strtotime(string $time [, int $now = time()] );

                    $nowDate = date("Y/m/d");

                      $string = $newID . "|" . $editFirstName . "|" . $editLastName . "|" . $editFavoriteSport . "|" . $nowTime3 . "|".$nowDate;

                    $countElements ++;


                    $newArrayAfterDeletion [$newArrayDeleteCounter]  = $string;
                    $countWriteData --;
                }
                else //  put every element back in array
                {

                    $newArrayAfterDeletion [$newArrayDeleteCounter]  = $arrayToDeleteID [$newArrayDeleteCounter];

                }


                $newArrayDeleteCounter --;
            }
        }
        $countForDeleteSearch --;
    }


    if ($countElements == 0) //  this number if > 0 if the item to delete is found in the file.  if the element is not found, it will return without attempting to delete a null value
    {
        return 25;
    }
    else // delete old file so we can re-write to it with the updated, edited data
    {
        $stringD = "data.txt";
        unlink ($stringD);
    }



    $textFile = "data.txt";

    $fileHandler = fopen($textFile, 'a') or die ("can't open file..");

    $space = "|";


//  perform some preliminary work before writing new data to file
    $countWriteData = $countWriteData + 1;

    if (flock ($fileHandler, LOCK_EX)) // lock file to insure correct data
    {
    while ($countWriteData > 0)
    {

        if ($newArrayAfterDeletion [$countWriteData] != "garbage")
        {


            $writeLine = $newArrayAfterDeletion [$countWriteData];
            $nowTime = time ();

            $time = time ();



            $nowTime3 = date ("g:i a.", time ());

            // $nowTime2 = strtotime(string $time [, int $now = time()] );

            $nowDate = date("Y/m/d");

//        fwrite($fileHandler, <br/>);

            fwrite($fileHandler, $writeLine);
            fwrite($fileHandler, "\r\n");

            $countWriteData --;
        }
        else
        {
            $countWriteData --;
        }
    }
    }
    else // if not flock
    {
        Echo "Error locking file";
    }
    fclose($fileHandler);


}


?>