<?php


$userInputOrder = $_GET['order'];
$searchPhrase = $_GET['q'];

$file = fopen("data.txt", "r");
$myArray = array();
$count = 0;


while (! feof($file)) //  no need to lock the file here as this is just a reader.  the file is locked below when it is written to
{
    $myArray [$count] = fgetcsv($file);

    $count = $count + 1;
}

fclose($file);

$newLine = "\r\n";


if ($userInputOrder == "asc")
{
    sort($myArray);
}
elseif ($userInputOrder == "desc")
{
    krsort ($myArray);
}
else
{
    sort ($myArray);
}
$counterValue = $count - 1;
$arrayToDeleteID = array();
$arrayExploded = array ();
$newArrayAfterDeletion = array();

if (! $searchPhrase)
{
foreach ($myArray as $d) {
    foreach($d as $v) {
        echo $v. "<br>";
    }
}
}

foreach ($myArray as $d) {
    foreach($d as $v) {
        $arrayToDeleteID [$counterValue] = $v;

        $counterValue --;
    }
}

$n1 = 0;


traverse($count, $arrayToDeleteID, $arrayExploded, $newArrayAfterDeletion, $searchPhrase);


function traverse ($count, $arrayToDeleteID, $arrayExploded, $newArrayAfterDeletion, $searchPhrase)
{
    $deleteID = "t45";
    $deleteCounter = $count - 1; //  counter used for deleting
    $newArrayDeleteCounter = $count - 1; //counter used when creating new array without deleted element
    $countWriteData = $count - 1; //  counter variable used when writing data

    $searchValue = $searchPhrase; //  characters the user wishes to search for

    $countValue = 0;

    while ($deleteCounter > 0)  //  explode array to retrive ID
    {

        $arrayExploded [$deleteCounter]  = (explode("|",$arrayToDeleteID[$deleteCounter]));

        $deleteCounter --;
    }


    $countForDeleteSearch = $count -1;
    $elementNotFound = "value found";
    $countElements = 0;
$newArrayDeleteCounter = 1;

    while ($countForDeleteSearch > 0) //  traverse array
    {
        //  this if statement checks if the user's search parameters is a substring of any first name's or last name's in the file
        if (strpos ($arrayExploded [$countForDeleteSearch] [1], $searchValue)  !== false || strpos ($arrayExploded [$countForDeleteSearch] [2], $searchValue)  !== false)

        {
            $newArrayAfterDeletion [$newArrayDeleteCounter]  = $arrayToDeleteID [$countForDeleteSearch];

            $countWriteData --;
            $countElements ++;
            $newArrayDeleteCounter ++;

		echo $arrayToDeleteID [$countForDeleteSearch];
		echo "<br/>";


        }
        else{
           //  the search parameters do not match any first or last names
        }
        $countForDeleteSearch --;
    }

}



?>