<?php

$userInputID = $_GET['id'];
$userInputFirstName = $_GET['FirstName'];
$userInputLastName = $_GET['LastName'];
$userInputFavoriteSport = $_GET['FavoriteSport'];



if (! $userInputFavoriteSport || ! $userInputLastName || ! $userInputFirstName || ! $userInputID)
{
    echo ("Error");
}
else
{


	$userInputFavoriteSport = str_replace('|', ' ', $userInputFavoriteSport); // Replaces all | with space ( ).
	$userInputFirstName = str_replace('|', ' ', $userInputFirstName);
	$userInputLastName = str_replace('|', ' ', $userInputLastName);
	$userInputID = str_replace('|', ' ', $userInputID);

    echo strtoupper("Add Successful!");
    saveData($userInputID, $userInputFirstName, $userInputLastName, $userInputFavoriteSport);
}


function createFile ()
{
    static $textFile = "data.txt";
}

function saveData ($IDInput, $firstNameInput, $lastNameInput, $favoriteSportInput)
{
    $textFile = "data.txt";


    $fileHandler = fopen($textFile, 'a') or die ("can't open file..");


    $space = "|";

    $ID = $IDInput;
    $firstName = $firstNameInput;
    $lastName = $lastNameInput;
    $favoriteSport = $favoriteSportInput;
    $nowTime = time ();

    $time = time ();



    $nowTime3 = date ("g:i a.", time ());


    $nowDate = date("Y/m/d");



    if (flock ($fileHandler, LOCK_EX))
    {

    fwrite($fileHandler, $ID);
    fwrite($fileHandler, $space);
    fwrite($fileHandler, $firstName);
    fwrite($fileHandler, $space);
    fwrite($fileHandler, $lastName);
    fwrite($fileHandler, $space);
    fwrite($fileHandler, $favoriteSport);
    fwrite($fileHandler, $space);
    fwrite($fileHandler, "$nowTime3" );
    fwrite($fileHandler, $space);
    fwrite($fileHandler, $nowDate);
    fwrite($fileHandler, "\r\n");

    flock ($fileHandler, LOCK_UN);
    }
    else{
        echo "Error Locking File ....";
    }
    fclose($fileHandler);

}

?>